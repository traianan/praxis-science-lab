Medical Terminology Flashcards — Praxis Science Lab
English Google Play preparation kit, 8 September 2026.
Support: traiananghel@gmail.com
Privacy policy: https://traianan.github.io/praxis-science-lab/apps/medical-terminology-flashcards/privacy/
Support and testing: https://traianan.github.io/praxis-science-lab/apps/medical-terminology-flashcards/support/
Declarations and outstanding checks: https://traianan.github.io/praxis-science-lab/apps/medical-terminology-flashcards/publishing/

The icon and feature graphic use their required pixel dimensions.
Screenshots: 0 genuine Android test-build captures, when available.
Calculator: 1.1.3 (5), English default. Utility captures use the current local Android build; clock captures use a debug-signed build with the actual app UI.
Revalidate all assets against the final signed upload artifact. No production medical content or fabricated screenshot is included.
This kit does not establish Google approval or completion of account verification, audience/rating forms or closed testing.

Remaining app-specific checks:
- Production educational content is absent. Do not publish the listing as a usable released learning product or reuse synthetic test screenshots.
- Final audience, health declaration, account type, advertising configuration, Data safety and manual accessibility/device checks remain open.
- The existing app's embedded policy and provisional URL still require a governed update to match this public policy before distribution.
