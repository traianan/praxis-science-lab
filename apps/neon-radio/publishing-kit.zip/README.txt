Neon Radio 0.12.0 (19). EN/RO/ES preparation kit. No signing keys or app binaries. Current build has commercial ads disabled. Website: https://traianan.github.io/praxis-science-lab/apps/neon-radio/
Captures are actual Android UI, debug-signed from the same source and TEST_ADS=false as the release. Complete owner declarations and pre-launch checks before submission.
