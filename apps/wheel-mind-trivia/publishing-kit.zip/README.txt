WheelMind Trivia — Praxis Science Lab
English Google Play preparation kit. Reviewed version: 1.0.1 (ARM64 APK 2002).
Support: traiananghel@gmail.com
Privacy policy: https://traianan.github.io/praxis-science-lab/apps/wheel-mind-trivia/privacy/
Support and testing: https://traianan.github.io/praxis-science-lab/apps/wheel-mind-trivia/support/
Declarations and outstanding checks: https://traianan.github.io/praxis-science-lab/apps/wheel-mind-trivia/publishing/

The icon and feature graphic use their required pixel dimensions.
Screenshots: 3 genuine Android test-build captures, when available.
Screenshot version: 1.0.0 (before the Settings advertising update). Captures may predate the current monetization update.
Revalidate all assets against the final signed upload artifact. No production medical content or fabricated screenshot is included.
This kit does not establish Google approval or completion of account verification, audience/rating forms or closed testing.

Remaining app-specific checks:
- Prepare and verify the production-signed Google Play AAB; current APKs are test-signed.
- Complete the intended audience, IARC rating, account verification and required testing in Play Console.
- Review the final configuration of advertising, billing, consent and Data safety before enabling store services.
- Review the question bank editorially and recheck screenshots against the final upload build.
