AURALIS 0.1.0 — public Google Play preparation materials
App: https://praxissciencelab.app/apps/auralis/
Privacy: https://praxissciencelab.app/apps/auralis/privacy/
Support: https://praxissciencelab.app/apps/auralis/support/
Support email: contact@praxissciencelab.app
Package: com.praxissciencelab.auralis
Version: 0.1.0 (1)

Includes text and authentic Android screenshots, not an installable or signed app.
No signing keys, app binaries, tester data or internal delivery archives.
Review against the final signed upload artifact before submission.
