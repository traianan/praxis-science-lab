Mosaic 0.5.0 — Praxis Science Lab
Public store assets only; no application binary, signing key or private data.
Privacy: https://traianan.github.io/praxis-science-lab/apps/mosaic/privacy/
Screenshots are real editor captures using original illustrative test images. Commercial advertising is not configured. Review final Play declarations before submission.
