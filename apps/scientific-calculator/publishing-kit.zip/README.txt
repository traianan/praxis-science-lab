Calculator Științific — Praxis Science Lab
English Google Play preparation kit, 8 September 2026.
Support: traiananghel@gmail.com
Privacy policy: https://traianan.github.io/praxis-science-lab/apps/scientific-calculator/privacy/
Support and testing: https://traianan.github.io/praxis-science-lab/apps/scientific-calculator/support/
Declarations and outstanding checks: https://traianan.github.io/praxis-science-lab/apps/scientific-calculator/publishing/

The icon and feature graphic use their required pixel dimensions.
Screenshots: 2 genuine Android test-build captures, when available.
Calculator: 1.1.3 (5), English default. Utility captures use the current local Android build; clock captures use a debug-signed build with the actual app UI.
Revalidate all assets against the final signed upload artifact. No production medical content or fabricated screenshot is included.
This kit does not establish Google approval or completion of account verification, audience/rating forms or closed testing.

Remaining app-specific checks:
- Final upload-key-signed AAB and verification on a physical Android device are still required.
- Complete account verification, actual audience/IARC forms, and the closed test required by the account.
