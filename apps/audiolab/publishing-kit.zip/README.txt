AudioLab — Praxis Science Lab
English Google Play preparation kit, 8 September 2026.
Support: traiananghel@gmail.com
Privacy policy: https://traianan.github.io/praxis-science-lab/apps/audiolab/privacy/
Support and testing: https://traianan.github.io/praxis-science-lab/apps/audiolab/support/
Declarations and outstanding checks: https://traianan.github.io/praxis-science-lab/apps/audiolab/publishing/

The icon and feature graphic use their required pixel dimensions.
Screenshots: 2 genuine Android test-build captures, when available.
Calculator: 1.1.3 (5), English default. Utility captures use the current local Android build; clock captures use a debug-signed build with the actual app UI.
Revalidate all assets against the final signed upload artifact. No production medical content or fabricated screenshot is included.
This kit does not establish Google approval or completion of account verification, audience/rating forms or closed testing.

Remaining app-specific checks:
- Verify microphone denial/revocation and foreground-only operation on the final signed build.
- Recheck the prepared screenshots against the final release and test native-library alignment, audio routes and exported-report accuracy on physical hardware.
