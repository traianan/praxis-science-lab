LuminaPro — Praxis Science Lab
English Google Play preparation kit. Reviewed version: 1.0.1 (2).
Support: traiananghel@gmail.com
Privacy policy: https://traianan.github.io/praxis-science-lab/apps/luminapro/privacy/
Support and testing: https://traianan.github.io/praxis-science-lab/apps/luminapro/support/
Declarations and outstanding checks: https://traianan.github.io/praxis-science-lab/apps/luminapro/publishing/

The icon and feature graphic use their required pixel dimensions.
Screenshots: 3 genuine Android test-build captures, when available.
Screenshot version: 1.0.0 (before the 1.0.1 monetization update). Captures may predate the current monetization update.
Revalidate all assets against the final signed upload artifact. No production medical content or fabricated screenshot is included.
This kit does not establish Google approval or completion of account verification, audience/rating forms or closed testing.

Remaining app-specific checks:
- Configure real advertising and store products, verify consent and audience declarations.
- Sign with the owner-approved production keys and verify both stores independently.
- Recheck actual ads, purchases, background behavior and final screenshots on representative devices.
